from flask import Flask, render_template, request, redirect, url_for, session, flash
import hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'  


users_db = {}
tasks_db = {}
ADMIN_EMAIL = "admin@taskmanager.com"


users_db[ADMIN_EMAIL] = {
    'password': hashlib.sha256("adminpass".encode()).hexdigest(),
    'profile': {'name': 'Admin', 'contact': '617-330-4459'},
    'role': 'admin',
    'failed_attempts': 0
}


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


@app.route("/")
def welcome():
    return render_template("welcome.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        if email in users_db:
            flash("User already exists.")
            return redirect(url_for('register'))
        users_db[email] = {
            'password': hash_password(password),
            'profile': {'name': '', 'contact': ''},
            'role': 'standard',
            'failed_attempts': 0
        }
        tasks_db[email] = []
        flash("Registered successfully! Please login.")
        return redirect(url_for('login'))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        user = users_db.get(email)
        if not user:
            flash("User not found.")
            return redirect(url_for('login'))
        if user['failed_attempts'] >= 5:
            flash("Account locked due to too many failed attempts.")
            return redirect(url_for('login'))
        if user['password'] == hash_password(password):
            session['user'] = email
            user['failed_attempts'] = 0
            return redirect(url_for('dashboard'))
        else:
            user['failed_attempts'] += 1
            flash("Wrong password.")
            return redirect(url_for('login'))
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    email = session['user']
    user_data = users_db.get(email)

    if not user_data:
        flash("Session error. Please log in again.")
        return redirect(url_for('logout'))

    user_tasks = tasks_db.get(email, [])
    completed_tasks = len([t for t in user_tasks if t['status'] == 'completed'])

    return render_template("dashboard.html", 
                           user=email, 
                           role=user_data['role'],
                           tasks=user_tasks,
                           completed_tasks=completed_tasks)


@app.route("/profile", methods=["GET", "POST"])
def profile():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    email = session['user']
    user_data = users_db.get(email)

    if not user_data:
        flash("Session expired or invalid user. Please log in again.")
        return redirect(url_for('logout'))

    profile = user_data['profile']

    if request.method == "POST":
        profile['name'] = request.form['name']
        profile['contact'] = request.form['contact']
        flash("Profile updated.")
        return redirect(url_for('profile'))

    return render_template("profile.html", profile=profile)


@app.route("/list_users")
def list_users():
    if 'user' not in session or users_db[session['user']]['role'] != 'admin':
        flash("Admin access only.")
        return redirect(url_for('dashboard'))
    return render_template("list_users.html", users=users_db)



@app.route("/tasks", methods=["GET", "POST"])
def tasks():
    if 'user' not in session:
        return redirect(url_for('login'))
    email = session['user']
    if request.method == "POST":
        task = {
            "id": len(tasks_db[email]) + 1,
            "name": request.form["name"],
            "due": request.form["due"],
            "priority": request.form["priority"],
            "desc": request.form["desc"],
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "to do",
            "completed_at": None
        }
        tasks_db[email].append(task)
        return redirect(url_for('tasks'))
    return render_template("tasks.html", tasks=tasks_db.get(email, []))

@app.route("/complete_task/<int:task_id>")
def complete_task(task_id):
    email = session.get('user')
    if not email:
        return redirect(url_for('login'))
    for task in tasks_db[email]:
        if task['id'] == task_id:
            task['status'] = 'completed'
            task['completed_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            break
    return redirect(url_for('tasks'))

@app.route("/logout")
def logout():
    session.pop('user', None)
    flash("Logged out.")
    return redirect(url_for('welcome'))

# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
